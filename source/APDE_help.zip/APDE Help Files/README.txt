O*NET Ability Profiler Data Entry Program
Version 1.1
-----------

This package contains the help files for the O*NET Ability Profiler
Data Entry Program.  To view these files, open the "index.html" file
in your preferred Web browser.

To download the latest version of the O*NET Ability Profiler
Data Entry Program, visit the O*NET Resource Center:

http://www.onetcenter.org/AP.html
